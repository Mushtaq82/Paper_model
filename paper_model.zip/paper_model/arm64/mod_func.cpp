#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;
#if defined(__cplusplus)
extern "C" {
#endif

extern void _AMPA_reg(void);
extern void _AMPA_SD_reg(void);
extern void _GABAa_reg(void);
extern void _GABAa_SD_reg(void);
extern void _GABAa_TC_reg(void);
extern void _GABAa_vlp_reg(void);
extern void _HH2_reg(void);
extern void _IT_reg(void);
extern void _IT2_reg(void);
extern void _ITREcustom_reg(void);
extern void _IT_old_reg(void);
extern void _Ih_reg(void);
extern void _Ih_old_reg(void);
extern void _Ipulse3_reg(void);
extern void _NMDA_reg(void);
extern void _autogoad_reg(void);
extern void _ca_reg(void);
extern void _cad_reg(void);
extern void _cadecay_reg(void);
extern void _ceil_reg(void);
extern void _gabab_reg(void);
extern void _hh_new_reg(void);
extern void _iA_reg(void);
extern void _im_reg(void);
extern void _ipulse1_reg(void);
extern void _kca_reg(void);
extern void _kl_reg(void);
extern void _kleak_reg(void);
extern void _kv_reg(void);
extern void _na_reg(void);
extern void _nap_reg(void);
extern void _nstim_reg(void);
extern void _tia_reg(void);
extern void _vecevent_reg(void);

void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"AMPA.mod\"");
    fprintf(stderr, " \"AMPA_SD.mod\"");
    fprintf(stderr, " \"GABAa.mod\"");
    fprintf(stderr, " \"GABAa_SD.mod\"");
    fprintf(stderr, " \"GABAa_TC.mod\"");
    fprintf(stderr, " \"GABAa_vlp.mod\"");
    fprintf(stderr, " \"HH2.mod\"");
    fprintf(stderr, " \"IT.mod\"");
    fprintf(stderr, " \"IT2.mod\"");
    fprintf(stderr, " \"ITREcustom.mod\"");
    fprintf(stderr, " \"IT_old.mod\"");
    fprintf(stderr, " \"Ih.mod\"");
    fprintf(stderr, " \"Ih_old.mod\"");
    fprintf(stderr, " \"Ipulse3.mod\"");
    fprintf(stderr, " \"NMDA.mod\"");
    fprintf(stderr, " \"autogoad.mod\"");
    fprintf(stderr, " \"ca.mod\"");
    fprintf(stderr, " \"cad.mod\"");
    fprintf(stderr, " \"cadecay.mod\"");
    fprintf(stderr, " \"ceil.mod\"");
    fprintf(stderr, " \"gabab.mod\"");
    fprintf(stderr, " \"hh_new.mod\"");
    fprintf(stderr, " \"iA.mod\"");
    fprintf(stderr, " \"im.mod\"");
    fprintf(stderr, " \"ipulse1.mod\"");
    fprintf(stderr, " \"kca.mod\"");
    fprintf(stderr, " \"kl.mod\"");
    fprintf(stderr, " \"kleak.mod\"");
    fprintf(stderr, " \"kv.mod\"");
    fprintf(stderr, " \"na.mod\"");
    fprintf(stderr, " \"nap.mod\"");
    fprintf(stderr, " \"nstim.mod\"");
    fprintf(stderr, " \"tia.mod\"");
    fprintf(stderr, " \"vecevent.mod\"");
    fprintf(stderr, "\n");
  }
  _AMPA_reg();
  _AMPA_SD_reg();
  _GABAa_reg();
  _GABAa_SD_reg();
  _GABAa_TC_reg();
  _GABAa_vlp_reg();
  _HH2_reg();
  _IT_reg();
  _IT2_reg();
  _ITREcustom_reg();
  _IT_old_reg();
  _Ih_reg();
  _Ih_old_reg();
  _Ipulse3_reg();
  _NMDA_reg();
  _autogoad_reg();
  _ca_reg();
  _cad_reg();
  _cadecay_reg();
  _ceil_reg();
  _gabab_reg();
  _hh_new_reg();
  _iA_reg();
  _im_reg();
  _ipulse1_reg();
  _kca_reg();
  _kl_reg();
  _kleak_reg();
  _kv_reg();
  _na_reg();
  _nap_reg();
  _nstim_reg();
  _tia_reg();
  _vecevent_reg();
}

#if defined(__cplusplus)
}
#endif
